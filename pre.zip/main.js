function navigatePage() {
    const selectedPage = document.getElementById('navbar').value;
    window.location.href = selectedPage;
}