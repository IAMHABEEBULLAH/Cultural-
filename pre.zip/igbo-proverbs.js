const educationalProverbs = [
    {
        title: "Ụkọ mma ekwe si na onye nwụrụ anwụ adịghị achọ ugwo.",
        description: "The debts of a dead person do not accumulate.",
        fullDescription: "This proverb teaches that one should clear their debts and responsibilities while alive, as no one does so after death. It encourages responsibility and diligence in managing obligations.",
        context: "Used to promote responsibility and proper management of obligations.",
    },
    {
        title: "Egbe belu ugo belu, nke siri ibe ya ebela, nku kwaa ya.",
        description: "Let the kite perch, let the eagle perch, and the one that prevents the other from perching may its wings break.",
        fullDescription: "This proverb encourages fairness and peaceful coexistence, warning against those who seek to suppress others.",
        context: "Often used to teach equality and peaceful coexistence in education and community life.",
    }
];

const maritalProverbs = [
    {
        title: "Agbọghọ nwanyi ji ego onye o gara uka asua akwa ka di nwayi jide.",
        description: "A woman who marries for money will one day find herself weeping in church.",
        fullDescription: "This proverb emphasizes the importance of marrying for love and mutual respect, rather than material wealth.",
        context: "Used to advise against materialism in marriage and encourage marrying for love and companionship.",
    },
    {
        title: "Nwunye gbaa ọsọ, di ekwuo okwu.",
        description: "When the wife runs away, the husband speaks.",
        fullDescription: "This proverb suggests that in marital relationships, communication is key, and when one party avoids dialogue, the other suffers.",
        context: "Used to emphasize the importance of open communication in marriage.",
    }
];

const successProverbs = [
    {
        title: "Onye kwuo uche ya, nwa nkita atụba ya n'ala.",
        description: "He who speaks his mind is not thrown to the ground by a puppy.",
        fullDescription: "This proverb teaches that success comes from being assertive and standing up for oneself, while timidity leads to failure.",
        context: "Used to encourage people to be confident and assertive in their pursuits.",
    },
    {
        title: "Ka ọ bụla onye nwere ụzọ ya ga-esi ere ọka.",
        description: "Each person has their own way of selling their corn.",
        fullDescription: "This proverb suggests that there are many paths to success, and each person should follow their own way.",
        context: "Used to promote individualism and diversity in achieving success.",
    }
];

const farmingProverbs = [
    {
        title: "Nwata bulie aka elu, ekwe ya na chi ya.",
        description: "When a child raises their hands, their chi (personal god) supports them.",
        fullDescription: "This proverb emphasizes the connection between effort and divine support in farming and life. It teaches that when one works hard, they will receive help from above.",
        context: "Used to encourage farmers and workers to give their best, trusting that their efforts will be rewarded.",
    },
    {
        title: "A sị m ụkwa gbutuo oke osisi ukwu, ọ gụrụ aka ọsọ.",
        description: "If I ask for breadfruit to fall and break the big tree, I should be prepared to run.",
        fullDescription: "This proverb teaches that one should be prepared for the consequences of their actions, especially in farming or life decisions.",
        context: "Used to caution people about being careful in making big decisions.",
    }
];

const livelihoodProverbs = [
    {
        title: "Onye ji mmiri agba ohu, ya buru nti.",
        description: "He who uses water to search for fish must be patient.",
        fullDescription: "This proverb emphasizes the importance of patience and strategy in achieving success in life and livelihood. It suggests that one should wait for the right moment.",
        context: "Used to teach patience in work and livelihood, encouraging people to wait for the right opportunities.",
    },
    {
        title: "Nwa nnunu jiri nwayo gbutuo okpukpu osisi.",
        description: "The bird that carefully pecks the tree gets the worm.",
        fullDescription: "This proverb teaches that success comes to those who are diligent and precise in their actions.",
        context: "Used to promote diligence and patience in livelihood and everyday activities.",
    }
];

function createProverbCard(proverb) {
    return `
    <div class="card">
        <div class="card-content">
            <h3>${proverb.title}</h3>
            <p>${proverb.description}</p>
            <p class="full-description" style="display:none">${proverb.fullDescription}</p>
            <p><strong>Context:</strong> ${proverb.context}</p>
            <button onclick="toggleReadMore(this)">Read More</button>
        </div>
    </div>
    `;
}

function populateIgboProverbs() {
    const educationalContainer = document.getElementById("educational-proverbs");
    const maritalContainer = document.getElementById("marital-proverbs");
    const successContainer = document.getElementById("success-proverbs");
    const farmingContainer = document.getElementById("farming-proverbs");
    const livelihoodContainer = document.getElementById("livelihood-proverbs");

    educationalProverbs.forEach(proverb => {
        educationalContainer.innerHTML += createProverbCard(proverb);
    });

    maritalProverbs.forEach(proverb => {
        maritalContainer.innerHTML += createProverbCard(proverb);
    });

    successProverbs.forEach(proverb => {
        successContainer.innerHTML += createProverbCard(proverb);
    });

    farmingProverbs.forEach(proverb => {
        farmingContainer.innerHTML += createProverbCard(proverb);
    });

    livelihoodProverbs.forEach(proverb => {
        livelihoodContainer.innerHTML += createProverbCard(proverb);
    });
}

function toggleReadMore(button) {
    const fullDescription = button.previousElementSibling;
    if (fullDescription.style.display === "none") {
        fullDescription.style.display = "block";
        button.textContent = "Read Less";
    } else {
        fullDescription.style.display = "none";
        button.textContent = "Read More";
    }
}

document.addEventListener('DOMContentLoaded', populateIgboProverbs);