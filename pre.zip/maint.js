const urbanEntertainment = [
    {
        title: "Modern Music Shows",
        description: "Live concerts featuring Hausa music stars like Sani Danja, Adam Zango, and more.",
        fullDescription: "These concerts include both traditional Hausa music and modern genres such as Afrobeat. They take place in urban centers like Kano and Abuja, drawing huge crowds. Famous musicians and bands participate, with fan interaction and exciting performances.",
        videoUrl: "videos/urban-music.mp4",
        imageUrl: "images/urban-music.jpg",
    },
    {
        title: "Cinema and Kannywood Films",
        description: "Urban Hausa entertainment also includes watching Kannywood films in cinemas.",
        fullDescription: "Kannywood is the Hausa-language cinema industry based in Northern Nigeria. Many cinemas showcase Hausa films, ranging from comedy to romance, featuring well-known actors and actresses. The industry's popularity has skyrocketed in recent years.",
        videoUrl: "videos/kannywood.mp4",
        imageUrl: "images/kannywood.jpg",
    },
    {
        title: "Cultural Fashion Shows",
        description: "Fashion shows that display Hausa traditional and modern attire.",
        fullDescription: "These fashion shows mix both traditional Hausa clothing, like 'Babban Riga' and 'Zanna Bukar,' with modern designs. They are often held during cultural festivals in major cities and attract fashion enthusiasts from across the country.",
        videoUrl: "videos/fashion-show.mp4",
        imageUrl: "culturalfashsion.jpg",
    }
];

const ruralEntertainment = [
    {
        title: "Hawan Sallah (Horse Riding Festivals)",
        description: "A traditional event where men show their horse-riding skills during Sallah celebrations.",
        fullDescription: "Hawan Sallah is a highly anticipated annual event that happens after the Eid prayers during Sallah celebrations. Men dressed in colorful traditional attire ride beautifully decorated horses through the streets, showcasing the rich heritage of horse riding in Hausa culture.",
        videoUrl: "videos/hawan-sallah.mp4",
        imageUrl: "images/hawan-sallah.jpg",
    },
    {
        title: "Sharo/Shadi Festival",
        description: "A rural tradition where young men engage in wrestling and endurance competitions.",
        fullDescription: "Sharo festivals are held during significant events, where young men prove their endurance and strength through wrestling matches and other endurance competitions. This event symbolizes manhood and bravery in Hausa communities.",
        videoUrl: "videos/sharo-festival.mp4",
        imageUrl: "images/sharo-festival.jpg",
    },
    {
        title: "Hausa Traditional Dance (Biki)",
        description: "Traditional Hausa dance is performed during rural wedding ceremonies.",
        fullDescription: "Dances like 'Biki' are an integral part of rural Hausa weddings. These dances are often accompanied by live traditional music and are performed by both men and women, adding vibrancy and joy to the occasion.",
        videoUrl: "videos/traditional-dance.mp4",
        imageUrl: "images/traditional-dance.jpg",
    }
];

function createCard(entertainment) {
    return `
    <div class="card">
        <img src="${entertainment.imageUrl}" alt="${entertainment.title}">
        <div class="card-content">
            <h3>${entertainment.title}</h3>
            <p>${entertainment.description}</p>
            <video controls>
                <source src="${entertainment.videoUrl}" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <p class="full-description" style="display:none">${entertainment.fullDescription}</p>
            <button onclick="toggleReadMore(this)">Read More</button>
        </div>
    </div>
    `;
}

function populateEntertainment() {
    const urbanEntertainmentContainer = document.getElementById("urban-entertainment");
    const ruralEntertainmentContainer = document.getElementById("rural-entertainment");

    urbanEntertainment.forEach(entertainment => {
        urbanEntertainmentContainer.innerHTML += createCard(entertainment);
    });

    ruralEntertainment.forEach(entertainment => {
        ruralEntertainmentContainer.innerHTML += createCard(entertainment);
    });
}

function toggleReadMore(button) {
    const fullDescription = button.previousElementSibling;
    if (fullDescription.style.display === "none") {
        fullDescription.style.display = "block";
        button.textContent = "Read Less";
    } else {
        fullDescription.style.display = "none";
        button.textContent = "Read More";
    }
}

document.addEventListener('DOMContentLoaded', populateEntertainment);