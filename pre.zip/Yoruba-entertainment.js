const urbanYorubaEntertainment = [
    {
        title: "Afrobeat Concerts",
        description: "Live concerts featuring top Afrobeat musicians like Burna Boy, Wizkid, and others.",
        fullDescription: "Afrobeat, a genre heavily influenced by Yoruba traditional music, is popular across the globe. Urban centers like Lagos regularly host large concerts with Afrobeat stars performing before thousands of fans.",
        videoUrl: "videos/afrobeat.mp4",
        imageUrl: "images/afrobeat.jpg",
    },
    {
        title: "Yoruba Theatre (Alaarinjo)",
        description: "Modern-day performances of traditional Yoruba traveling theatre.",
        fullDescription: "Yoruba theatre, known as 'Alaarinjo,' is a form of performance art that combines dance, drama, and music. Today, urban adaptations can be seen in theatres, often blending traditional elements with contemporary plots.",
        videoUrl: "videos/yoruba-theatre.mp4",
        imageUrl: "images/yoruba-theatre.jpg",
    },
    {
        title: "Cultural Festivals (Eyo Festival)",
        description: "The Eyo festival is a grand urban Yoruba celebration.",
        fullDescription: "Eyo Festival, also known as the Adamu Orisha Play, is an urban festival celebrated in Lagos. During the festival, participants dress in white robes, parading through the streets to honor the deities and ancestors. It's a spectacle of colors, songs, and dances.",
        videoUrl: "videos/eyo-festival.mp4",
        imageUrl: "images/eyo-festival.jpg",
    }
];

const ruralYorubaEntertainment = [
    {
        title: "Egungun Masquerade Festival",
        description: "A rural celebration that honors Yoruba ancestors through colorful masquerades.",
        fullDescription: "The Egungun festival is a traditional Yoruba event where the community worships ancestors. Masqueraders, believed to represent the spirits of ancestors, perform energetic dances during the festival, which takes place in villages and rural towns.",
        videoUrl: "videos/egungun-festival.mp4",
        imageUrl: "images/egungun-festival.jpg",
    },
    {
        title: "Traditional Yoruba Drumming",
        description: "Drumming is an essential part of Yoruba rural ceremonies, including weddings and naming ceremonies.",
        fullDescription: "Yoruba drumming is a deep-rooted cultural practice. The talking drum ('Dundun') and the bata drum are often played at rural events such as weddings, funerals, and religious festivals, creating a rhythmic connection between the people and their ancestors.",
        videoUrl: "videos/yoruba-drumming.mp4",
        imageUrl: "images/yoruba-drumming.jpg",
    },
    {
        title: "Yoruba Traditional Dance (Bata Dance)",
        description: "A rural dance often performed during major celebrations like coronations.",
        fullDescription: "The Bata dance is a high-energy Yoruba dance, performed during celebrations and ceremonies. Dancers engage in rapid movements to the beats of the talking drum, showing off their skills and stamina. It is particularly popular during coronation ceremonies of traditional rulers.",
        videoUrl: "videos/bata-dance.mp4",
        imageUrl: "images/bata-dance.jpg",
    }
];

function createYorubaCard(entertainment) {
    return `
    <div class="card">
        <img src="${entertainment.imageUrl}" alt="${entertainment.title}">
        <div class="card-content">
            <h3>${entertainment.title}</h3>
            <p>${entertainment.description}</p>
            <video controls>
                <source src="${entertainment.videoUrl}" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <p class="full-description" style="display:none">${entertainment.fullDescription}</p>
            <button onclick="toggleReadMore(this)">Read More</button>
        </div>
    </div>
    `;
}

function populateYorubaEntertainment() {
    const urbanEntertainmentContainer = document.getElementById("urban-entertainment-yoruba");
    const ruralEntertainmentContainer = document.getElementById("rural-entertainment-yoruba");

    urbanYorubaEntertainment.forEach(entertainment => {
        urbanEntertainmentContainer.innerHTML += createYorubaCard(entertainment);
    });

    ruralYorubaEntertainment.forEach(entertainment => {
        ruralEntertainmentContainer.innerHTML += createYorubaCard(entertainment);
    });
}

function toggleReadMore(button) {
    const fullDescription = button.previousElementSibling;
    if (fullDescription.style.display === "none") {
        fullDescription.style.display = "block";
        button.textContent = "Read Less";
    } else {
        fullDescription.style.display = "none";
        button.textContent = "Read More";
    }
}

document.addEventListener('DOMContentLoaded', populateYorubaEntertainment);