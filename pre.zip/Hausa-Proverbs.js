const educationalProverbs = [
    {
        title: "Ilmi shi ne haske",
        description: "Education is light.",
        fullDescription: "This proverb emphasizes the value of education, as it illuminates the path of life. Just like light shows the way, knowledge guides individuals to make better decisions and improve their lives.",
        context: "Used to encourage learning and highlight the importance of education.",
    },
    {
        title: "Wanda bai san darajar ilmi ba, yana kama da wanda bai gani ba.",
        description: "He who does not value knowledge is like the blind.",
        fullDescription: "This highlights the significance of valuing education, comparing ignorance to blindness. It encourages people to pursue education as a tool for enlightenment.",
        context: "Used in educational settings to stress the importance of learning.",
    }
];

const maritalProverbs = [
    {
        title: "Rabin rai aure ne.",
        description: "Half of life is marriage.",
        fullDescription: "This proverb indicates the importance of marriage in Hausa culture, as it is seen as fulfilling half of one's life responsibilities. It conveys the idea that marriage brings completeness.",
        context: "Often used in the context of marriage and family life, to encourage people to take marriage seriously.",
    },
    {
        title: "Zama da kishiya ba shi da dadi, amma maganin haka hakuri ne.",
        description: "Living with a co-wife is difficult, but patience is the remedy.",
        fullDescription: "This proverb highlights the difficulties that can arise in polygamous marriages, advising patience as the key to managing such relationships.",
        context: "Used to counsel patience and understanding in marriage, especially in polygamous settings.",
    }
];

const successProverbs = [
    {
        title: "Da hange ake samun nasara.",
        description: "Success comes with foresight.",
        fullDescription: "This proverb stresses the importance of planning and having foresight when pursuing success. It teaches that those who plan ahead are more likely to achieve their goals.",
        context: "Often used to encourage people to think ahead and plan for success.",
    },
    {
        title: "Aiki da gaskiya yana kai ga nasara.",
        description: "Honesty in work leads to success.",
        fullDescription: "This proverb promotes the value of honesty and hard work, teaching that those who are truthful and diligent in their efforts will be rewarded with success.",
        context: "Used to encourage integrity in business and professional endeavors.",
    }
];

const farmingProverbs = [
    {
        title: "Mai noman dare shi ke cin rana.",
        description: "He who farms in the night reaps during the day.",
        fullDescription: "This proverb emphasizes hard work and dedication, suggesting that those who put in effort, even in difficult conditions, will eventually enjoy the fruits of their labor.",
        context: "Used to encourage farmers and others who work hard to stay patient, as their efforts will be rewarded.",
    },
    {
        title: "Gona tana ci ne idan an kula da ita.",
        description: "A farm yields when it is well taken care of.",
        fullDescription: "This highlights the importance of dedication and proper care in farming, teaching that successful farming requires consistent attention and effort.",
        context: "Often used to emphasize the value of hard work and persistence, especially in agriculture.",
    }
];

const livelihoodProverbs = [
    {
        title: "Ruwa baya tsami banza.",
        description: "Water does not become sour for no reason.",
        fullDescription: "This proverb implies that things do not go wrong without a cause. It teaches the importance of understanding the root causes of problems before reacting.",
        context: "Used in livelihood contexts to explain that challenges usually arise for a reason, encouraging reflection.",
    },
    {
        title: "Mai hankali ya fi karfi.",
        description: "Wisdom is better than strength.",
        fullDescription: "This proverb teaches that wisdom and good judgment are more valuable than physical strength when it comes to overcoming life's challenges.",
        context: "Used to promote the importance of intelligence and good decision-making in daily life.",
    }
];

function createProverbCard(proverb) {
    return `
    <div class="card">
        <div class="card-content">
            <h3>${proverb.title}</h3>
            <p>${proverb.description}</p>
            <p class="full-description" style="display:none">${proverb.fullDescription}</p>
            <p><strong>Context:</strong> ${proverb.context}</p>
            <button onclick="toggleReadMore(this)">Read More</button>
        </div>
    </div>
    `;
}

function populateHausaProverbs() {
    const educationalContainer = document.getElementById("educational-proverbs");
    const maritalContainer = document.getElementById("marital-proverbs");
    const successContainer = document.getElementById("success-proverbs");
    const farmingContainer = document.getElementById("farming-proverbs");
    const livelihoodContainer = document.getElementById("livelihood-proverbs");

    educationalProverbs.forEach(proverb => {
        educationalContainer.innerHTML += createProverbCard(proverb);
    });

    maritalProverbs.forEach(proverb => {
        maritalContainer.innerHTML += createProverbCard(proverb);
    });

    successProverbs.forEach(proverb => {
        successContainer.innerHTML += createProverbCard(proverb);
    });

    farmingProverbs.forEach(proverb => {
        farmingContainer.innerHTML += createProverbCard(proverb);
    });

    livelihoodProverbs.forEach(proverb => {
        livelihoodContainer.innerHTML += createProverbCard(proverb);
    });
}

function toggleReadMore(button) {
    const fullDescription = button.previousElementSibling;
    if (fullDescription.style.display === "none") {
        fullDescription.style.display = "block";
        button.textContent = "Read Less";
    } else {
        fullDescription.style.display = "none";
        button.textContent = "Read More";
    }
}

document.addEventListener('DOMContentLoaded', populateHausaProverbs);