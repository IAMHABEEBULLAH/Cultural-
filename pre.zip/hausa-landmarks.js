const homeLandmarks = [
    {
        title: "Emir's Palace, Kano",
        description: "The Emir's Palace in Kano is a symbol of Hausa royalty and a testament to traditional Hausa architecture.",
        fullDescription: "The Emir’s Palace is a historical landmark, built in the 15th century. It serves as the residence of the Emir of Kano and is an important cultural site that attracts tourists from all over the world.",
        imageUrl: "emir_palace_kano.jpg"
    },
    {
        title: "Gidan Makama Museum, Kano",
        description: "A museum that offers a rich display of Hausa culture and history.",
        fullDescription: "Gidan Makama Museum is a historic building in Kano City, now turned into a museum showcasing Hausa history, culture, and the significance of Kano in Nigeria’s history. It contains artifacts, traditional garments, and tools used by the Hausa people.",
        imageUrl: "gidan_makama.jpg"
    },
    {
        title: "Zuma Rock, Abuja-Kaduna Road",
        description: "A natural rock formation that serves as a cultural symbol to the Hausa people.",
        fullDescription: "Zuma Rock, located on the border of Niger State and the Federal Capital Territory (Abuja), is often referred to as the 'Gateway to the North.' This monumental rock is a sacred site to many Hausa people and holds cultural and spiritual significance.",
        imageUrl: "zuma_rock.jpg"
    }
];

const abroadLandmarks = [
    {
        title: "Hausa Diaspora, Sudan",
        description: "Hausa communities established in Sudan have historical roots and maintain cultural traditions.",
        fullDescription: "The Hausa people migrated to Sudan centuries ago due to trade and pilgrimage routes. Today, they form a significant part of the Sudanese society, maintaining their language, culture, and traditions through festivals and cultural exchanges.",
        imageUrl: "hausa_sudan.jpg"
    },
    {
        title: "Sultan Bello Mosque, Ghana",
        description: "A historic mosque that stands as a reminder of Hausa Islamic influence in West Africa.",
        fullDescription: "Sultan Bello Mosque in Accra, Ghana, was built by Hausa traders and settlers. It is a place of worship and a cultural center for the Hausa community in Ghana, symbolizing the spread of Hausa culture across West Africa.",
        imageUrl: "sultan_bello_ghana.jpg"
    },
    {
        title: "Hausa Quarter, Mecca, Saudi Arabia",
        description: "A neighborhood in Mecca where Hausa pilgrims have historically settled.",
        fullDescription: "The Hausa Quarter in Mecca dates back to the centuries-old Hajj pilgrimage. Hausa pilgrims established a community in the Holy City, creating a place of cultural exchange and religious significance that continues to this day.",
        imageUrl: "hausa_mecca.jpg"
    }
];

function createLandmarkCard(landmark) {
    return `
    <div class="card">
        <img src="${landmark.imageUrl}" alt="${landmark.title}" class="card-img">
        <div class="card-content">
            <h3>${landmark.title}</h3>
            <p>${landmark.description}</p>
            <p class="full-description" style="display:none">${landmark.fullDescription}</p>
            <button onclick="toggleReadMore(this)">Read More</button>
        </div>
    </div>
    `;
}

function populateHausaLandmarks() {
    const homeContainer = document.getElementById("home-landmarks");
    const abroadContainer = document.getElementById("abroad-landmarks");

    homeLandmarks.forEach(landmark => {
        homeContainer.innerHTML += createLandmarkCard(landmark);
    });

    abroadLandmarks.forEach(landmark => {
        abroadContainer.innerHTML += createLandmarkCard(landmark);
    });
}

function toggleReadMore(button) {
    const fullDescription = button.previousElementSibling;
    if (fullDescription.style.display === "none") {
        fullDescription.style.display = "block";
        button.textContent = "Read Less";
    } else {
        fullDescription.style.display = "none";
        button.textContent = "Read More";
    }
}

document.addEventListener('DOMContentLoaded', populateHausaLandmarks);