const urbanIgboEntertainment = [
    {
        title: "Afropop Music and Concerts",
        description: "Modern Afropop performances featuring Igbo artists like Flavour, Phyno, and others.",
        fullDescription: "Afropop, a fusion of traditional Igbo music and modern genres, has gained significant popularity in urban areas. Artists like Flavour and Phyno bring a mix of Igbo culture to their music. These concerts are major urban events.",
        videoUrl: "videos/afropop.mp4",
        imageUrl: "images/afropop.jpg",
    },
    {
        title: "Nollywood Film Industry",
        description: "The vibrant Nollywood industry, known for Igbo-themed movies.",
        fullDescription: "Nollywood, the Nigerian movie industry, is a significant part of urban Igbo entertainment. Many films portray Igbo traditions, family structures, and cultural stories, gaining global recognition.",
        videoUrl: "videos/nollywood.mp4",
        imageUrl: "images/nollywood.jpg",
    },
    {
        title: "New Yam Festival (Iri Ji)",
        description: "An annual urban and rural celebration of the New Yam harvest, with dances and music.",
        fullDescription: "The New Yam Festival, also known as 'Iri Ji,' is celebrated by both urban and rural communities. In cities, the festival has evolved to include more modern forms of entertainment like music concerts, parades, and dance competitions.",
        videoUrl: "videos/new-yam-festival.mp4",
        imageUrl: "images/new-yam-festival.jpg",
    }
];

const ruralIgboEntertainment = [
    {
        title: "Igbo Masquerade Festival (Mmanwu)",
        description: "Rural Igbo communities celebrate with colorful masquerades.",
        fullDescription: "The Mmanwu festival features masquerades that are believed to represent ancestral spirits. The festival includes vibrant dances, music, and storytelling. Rural communities use it as a way to honor tradition and ancestors.",
        videoUrl: "videos/masquerade-festival.mp4",
        imageUrl: "images/masquerade-festival.jpg",
    },
    {
        title: "Igbo Wrestling (Mgba)",
        description: "A traditional Igbo sport held during festivals in rural areas.",
        fullDescription: "Wrestling, or 'Mgba,' is a popular traditional sport among the Igbo people, especially in rural areas. It's often part of larger festivals and is accompanied by drumming and singing. Participants compete in strength and skill to earn respect in the community.",
        videoUrl: "videos/igbo-wrestling.mp4",
        imageUrl: "images/igbo-wrestling.jpg",
    },
    {
        title: "Traditional Igbo Dance (Atilogwu)",
        description: "A high-energy dance performed in rural areas during celebrations.",
        fullDescription: "Atilogwu is a traditional Igbo dance characterized by its acrobatic movements and vibrant energy. Performed during festivals, it showcases the dexterity and agility of dancers and is a crowd favorite at rural events.",
        videoUrl: "videos/atilogwu-dance.mp4",
        imageUrl: "images/atilogwu-dance.jpg",
    }
];

function createIgboCard(entertainment) {
    return `
    <div class="card">
        <img src="${entertainment.imageUrl}" alt="${entertainment.title}">
        <div class="card-content">
            <h3>${entertainment.title}</h3>
            <p>${entertainment.description}</p>
            <video controls>
                <source src="${entertainment.videoUrl}" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <p class="full-description" style="display:none">${entertainment.fullDescription}</p>
            <button onclick="toggleReadMore(this)">Read More</button>
        </div>
    </div>
    `;
}

function populateIgboEntertainment() {
    const urbanEntertainmentContainer = document.getElementById("urban-entertainment-igbo");
    const ruralEntertainmentContainer = document.getElementById("rural-entertainment-igbo");

    urbanIgboEntertainment.forEach(entertainment => {
        urbanEntertainmentContainer.innerHTML += createIgboCard(entertainment);
    });

    ruralIgboEntertainment.forEach(entertainment => {
        ruralEntertainmentContainer.innerHTML += createIgboCard(entertainment);
    });
}

function toggleReadMore(button) {
    const fullDescription = button.previousElementSibling;
    if (fullDescription.style.display === "none") {
        fullDescription.style.display = "block";
        button.textContent = "Read Less";
    } else {
        fullDescription.style.display = "none";
        button.textContent = "Read More";
    }
}

document.addEventListener('DOMContentLoaded', populateIgboEntertainment);