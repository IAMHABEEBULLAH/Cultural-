function showDictionaryDetails() {
    const languageGroup = document.getElementById('language-group').value;
    const dictionaryDetails = document.getElementById('dictionary-details');
    const dictionaryTitle = document.getElementById('dictionary-title');
    const wordList = document.getElementById('word-list');

    // Clear previous words
    wordList.innerHTML = '';

    const dictionaryInfo = {
        hausa: {
            title: 'Hausa Dictionary',
            words: [
                { word: 'Gida', translation: 'House' },
                { word: 'Rana', translation: 'Sun' },
                { word: 'Mutum', translation: 'Person' }
            ]
        },
        igbo: {
            title: 'Igbo Dictionary',
            words: [
                { word: 'Ụlọ', translation: 'House' },
                { word: 'Anya', translation: 'Eye' },
                { word: 'Mmiri', translation: 'Water' }
            ]
        },
        yoruba: {
            title: 'Yoruba Dictionary',
            words: [
                { word: 'Ilé', translation: 'House' },
                { word: 'Ojú', translation: 'Eye' },
                { word: 'Omi', translation: 'Water' }
            ]
        }
    };

    if (dictionaryInfo[languageGroup]) {
        dictionaryTitle.textContent = dictionaryInfo[languageGroup].title;
        dictionaryInfo[languageGroup].words.forEach(entry => {
            const listItem = document.createElement('li');
            listItem.textContent = `${entry.word} - ${entry.translation}`;
            wordList.appendChild(listItem);
        });
        dictionaryDetails.classList.remove('hidden');
    } else {
        dictionaryDetails.classList.add('hidden');
    }
}