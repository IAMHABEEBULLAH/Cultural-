const educationalProverbs = [
    {
        title: "Iṣẹ́ ni òògùn ìṣẹ́.",
        description: "Hard work is the remedy for poverty.",
        fullDescription: "This proverb teaches that the solution to poverty and lack is hard work. It encourages people to be diligent in their efforts.",
        context: "Used to promote hard work and discourage laziness.",
    },
    {
        title: "Ọmọ tó bá mọ̀ràn, ọ̀rọ̀ ni yóò gbo.",
        description: "A sensible child listens to advice.",
        fullDescription: "This proverb emphasizes the value of heeding advice, especially from elders. It suggests that wisdom comes from listening.",
        context: "Used to teach children the importance of listening to good advice from elders.",
    }
];

const maritalProverbs = [
    {
        title: "Ìfẹ́ lóògùn àìsàn.",
        description: "Love is the remedy for all sickness.",
        fullDescription: "This proverb shows the power of love in overcoming difficulties, especially in marital relationships. It suggests that love can heal wounds and solve problems.",
        context: "Often used to encourage peace and love between married couples.",
    },
    {
        title: "Ọkọ́ tó bá ṣojú, aláyé rẹ̀ yóò di ‘gbogbo-gbigbá.",
        description: "A careful husband brings fortune to his home.",
        fullDescription: "This proverb stresses the importance of a husband's diligence and attention to his home. It suggests that when a man is careful, his household will prosper.",
        context: "Used to emphasize the role of responsibility in marriage.",
    }
];

const successProverbs = [
    {
        title: "A kì í ṣègbé sùn ki a jí lọ́mọ n láti ṣògo.",
        description: "One does not sleep in disaster and wake up to greatness.",
        fullDescription: "This proverb teaches that success does not come without hard work. One cannot ignore their responsibilities and expect to wake up to success.",
        context: "Used to motivate people to take action toward achieving success.",
    },
    {
        title: "Ìsùnkan kò sùúrù ló ńfún ọ̀pọ̀lọ́ àti ẹja.",
        description: "Patience feeds the frog and fish in the stream.",
        fullDescription: "This proverb emphasizes the importance of patience, as even the simplest creatures benefit from waiting. It suggests that success takes time and patience.",
        context: "Often used to teach the value of patience in achieving success.",
    }
];

const farmingProverbs = [
    {
        title: "Ẹni tó bá rọ ọ̀rọ̀ tó ńsè ni, òun ni wọ́n á gbéyè fún.",
        description: "He who waters the field eats the fruit.",
        fullDescription: "This proverb emphasizes the rewards of hard work and effort in farming. It teaches that only those who work diligently will enjoy the benefits of their labor.",
        context: "Used to encourage farmers and workers to continue their efforts with the promise of future rewards.",
    },
    {
        title: "Ọ̀pọ̀lọ́ kò jìyan pàdé igbó.",
        description: "The frog does not argue when it reaches the forest.",
        fullDescription: "This proverb teaches that one must adjust to their environment, particularly in farming or nature. It also implies that it is wise to be silent in certain situations.",
        context: "Used to emphasize the importance of adapting to different environments, especially in farming.",
    }
];

const livelihoodProverbs = [
    {
        title: "Ẹni tó bá ṣe ilé, ilé rẹ̀ á mú’ra wọ.",
        description: "He who builds a house, his home will shelter him.",
        fullDescription: "This proverb stresses the importance of preparation and hard work in building one’s livelihood. It suggests that those who work hard for their homes will benefit from the comfort it provides.",
        context: "Used to teach the importance of building and investing in one’s life and family.",
    },
    {
        title: "Ọgbọn jẹ́ ọ̀pọ̀lọ́, ibùdó rẹ ni agbada.",
        description: "The frog has wisdom, but its knowledge lies in the pond.",
        fullDescription: "This proverb emphasizes the importance of knowing one’s environment and making wise decisions based on it. It teaches that wisdom is relative to the situation.",
        context: "Used to explain that every person has a domain in which they excel.",
    }
];

function createProverbCard(proverb) {
    return `
    <div class="card">
        <div class="card-content">
            <h3>${proverb.title}</h3>
            <p>${proverb.description}</p>
            <p class="full-description" style="display:none">${proverb.fullDescription}</p>
            <p><strong>Context:</strong> ${proverb.context}</p>
            <button onclick="toggleReadMore(this)">Read More</button>
        </div>
    </div>
    `;
}

function populateYorubaProverbs() {
    const educationalContainer = document.getElementById("educational-proverbs");
    const maritalContainer = document.getElementById("marital-proverbs");
    const successContainer = document.getElementById("success-proverbs");
    const farmingContainer = document.getElementById("farming-proverbs");
    const livelihoodContainer = document.getElementById("livelihood-proverbs");

    educationalProverbs.forEach(proverb => {
        educationalContainer.innerHTML += createProverbCard(proverb);
    });

    maritalProverbs.forEach(proverb => {
        maritalContainer.innerHTML += createProverbCard(proverb);
    });

    successProverbs.forEach(proverb => {
        successContainer.innerHTML += createProverbCard(proverb);
    });

    farmingProverbs.forEach(proverb => {
        farmingContainer.innerHTML += createProverbCard(proverb);
    });

    livelihoodProverbs.forEach(proverb => {
        livelihoodContainer.innerHTML += createProverbCard(proverb);
    });
}

function toggleReadMore(button) {
    const fullDescription = button.previousElementSibling;
    if (fullDescription.style.display === "none") {
        fullDescription.style.display = "block";
        button.textContent = "Read Less";
    } else {
        fullDescription.style.display = "none";
        button.textContent = "Read More";
    }
}

document.addEventListener('DOMContentLoaded', populateYorubaProverbs);